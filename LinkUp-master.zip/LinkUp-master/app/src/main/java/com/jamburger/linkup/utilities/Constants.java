package com.jamburger.linkup.utilities;

public class Constants {
    public static final String TAG = "com.jamburger.kitter";
}
